//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//// array of dictionary words
//var arr = Array<String>()
//func appendWords() {
//    let contents = readFile("//Users/Cat/Downloads/randomtext.txt")
//    contents?.enumerateLines {
//        line, stop in
//        if line != "" {
//            arr.append(line)
//        }
//    }
//}
//
//
//// reads a file
//func readFile(filePath: String) -> String? {
//    do {
//        let str = try String(contentsOfFile: filePath)
//        return str
//    } catch {
//        return nil
//    }
//}
//
//appendWords()
//
//arr

//var array = Array<String>()
//array.append("a")
//array.append("b")
//
//for i in 0...array.count-1 {
//    print(array[i])
//}

let n = random()
print(n)
